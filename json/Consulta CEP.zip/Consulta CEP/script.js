async function pesquisaCepPeloEndereco (){

    const estado = document.getElementById("estado").value
    const cidade = document.getElementById("cidade").value
    const rua = document.getElementById("rua").value

    if (estado == '' || cidade == '' || rua == '') {
        alert("Digite todos os campos por gentileza")
    }
    else {
        const conteudo = document.getElementById("conteudo")

        try {
            const url = 'https://viacep.com.br/ws/' + estado + '/' + cidade + '/' + rua + '/json/'
            const resposta = await fetch(url)
            const dados = await resposta.json();
            dados.forEach(function(dadosEndereco){
                const paragrafos = document.createElement('p')
                paragrafos.textContent = `CEP: ${dadosEndereco.cep}`
                conteudo.appendChild(paragrafos)
            })
        } catch (error) {
            alert("Dados inseridos incorretamente" + error);
        }
    }
}